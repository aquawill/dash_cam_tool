"""curses.panel

Module for using panels with curses.
"""

__revision__ = "$Id$"

from _curses_panel import *
